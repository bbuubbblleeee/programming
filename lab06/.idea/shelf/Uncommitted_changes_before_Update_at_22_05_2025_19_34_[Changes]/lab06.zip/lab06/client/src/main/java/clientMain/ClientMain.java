package clientMain;

import client.ReadData;
import io.ConsoleReader;
import io.MyReader;
import transfer.Request;



public class ClientMain {
    public static void main(String[] args){
        try {
            Client client = new Client();
            MyReader myReader = new ConsoleReader();
            ReadData readData = new ReadData();
            while (myReader.hasNextLine()) {
                Handler handler = new Handler(myReader.readLine(), readData);
                Request request = handler.getRequest();
                System.out.println("реквест получен");

                client.sendRequest(request);
                System.out.println("успех");


                System.out.println(client.recieveResponse().toString());

            }
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}