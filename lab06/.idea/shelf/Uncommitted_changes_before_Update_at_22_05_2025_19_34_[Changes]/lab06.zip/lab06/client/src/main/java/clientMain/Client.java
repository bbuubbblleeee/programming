package clientMain;

import transfer.Request;
import transfer.Response;

import javax.annotation.processing.Messager;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;

import static transfer.Serializer.deserialize;
import static transfer.Serializer.serialize;

public class Client {
    private int port = 1234;
    private SocketAddress serverAddress;
    private DatagramChannel channel;
    private static final int TIME_OUT = 5000;
    public Client () throws IOException {
        serverAddress = new InetSocketAddress("localhost", port);

        channel = DatagramChannel.open();
        channel.configureBlocking(false);
        channel.connect(serverAddress);
        System.out.println("Клиент создан.");
    }

    public void sendRequest(Request request) throws IOException {
        ByteBuffer byteBuffer = ByteBuffer.allocate(65535);
        byteBuffer = ByteBuffer.wrap(serialize(request));
        channel.write(byteBuffer);
    }

    public Response recieveResponse() throws IOException, ClassNotFoundException {
        ByteBuffer byteBuffer = ByteBuffer.allocate(65535);
        long startTime = System.currentTimeMillis();

        while (System.currentTimeMillis() - startTime < TIME_OUT) {
            if (channel.receive(byteBuffer) == null){
                continue;
            }
            byteBuffer.flip(); // переходим от записи в буфер к чтению

            byte[] data = new byte[byteBuffer.limit()];
            byteBuffer.get(data);

            Object object = deserialize(data);
            if (object instanceof Response response) {
                return response;
            }
            return new Response("Ошибка: получен неожиданный тип объекта.");
        }
        return new Response("Ошибка: нет ответа от сервера.");
    }


}
