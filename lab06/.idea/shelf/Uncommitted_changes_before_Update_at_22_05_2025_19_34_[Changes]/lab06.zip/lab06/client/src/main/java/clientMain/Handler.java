package clientMain;

import client.ReadData;
import collection.Dragon;
import transfer.Request;

import java.util.ArrayList;


/**
 * The class is the handler of a user request.
 * <p>
 * The class parses the command entered by the user, checks the number and correctness of arguments
 * and creates a {@link Request} object containing the command, arguments and a list of {@link Dragon} objects, if required.
 * </p>
 */
public class Handler {
    private final String request;
    private final ReadData readData;
    public Handler(String string, ReadData readData){
        this.request = string;
        this.readData = readData;
    }

    public Request getRequest() throws InterruptedException {
        ArrayList<Dragon> dragons = new ArrayList<>();
        String[] input = request.trim().split("\\s+", 2);
        String commandStr = input[0];
        String[] args = input.length > 1 ? input[1].trim().split("\\s+") : new String[0];
        if (commandStr.equals("update") || commandStr.equals("add")){
            dragons.add(readData.get());
            return new Request(commandStr, args, dragons, this.readData);
        }
        return new Request(commandStr, args, dragons);
    }
}
