package collection;

import java.io.Serializable;

/**
 * Color enumeration.
 */

public enum Color implements Serializable {
    GREEN,
    BLACK,
    WHITE
}

