rootProject.name = "lab06"
include("server")
include("client")
include("common")
