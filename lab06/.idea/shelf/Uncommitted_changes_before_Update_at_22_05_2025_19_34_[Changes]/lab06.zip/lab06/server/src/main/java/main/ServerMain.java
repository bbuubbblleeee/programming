package main;

import collection.Dragon;
import collectionManager.CollectionManager;
import collectionManager.InMemoryCollection;
import commands.Command;
import exceptions.InvalidCommandException;
import exceptions.InvalidFileException;
import exceptions.WrongNumberOfArguments;
import invoker.Invoker;
import transfer.Request;
import transfer.Response;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.io.*;


import java.util.Arrays;
import java.util.Stack;

import static invoker.CommandsStorage.commands;
import static transfer.Serializer.deserialize;
import static transfer.Serializer.serialize;


public class ServerMain {
    private static final Stack<String> pathStack = new Stack<>();
    private static final CollectionManager collectionManager = new InMemoryCollection();
    public static void main(String[] args) {
        try {
            DatagramSocket datagramSocket = new DatagramSocket(1234);
            byte[] buffer = new byte[65535];

            System.out.println("Сервер запущен...");

            while (true) {
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                datagramSocket.receive(packet);

                byte[] realData = Arrays.copyOf(packet.getData(), packet.getLength());
                System.out.println("Ща будет десериализация");
                Request request = (Request) deserialize(realData);
                System.out.println("Получен запрос от клиента.");

                if (request.command() == null) {
                    throw new InvalidCommandException();
                }
                Command command = findCommand(request.command());
                String[] arguments = request.args();
                if (arguments.length != command.getRequiredArgs()) {
                    throw new WrongNumberOfArguments();
                }
                if (command.getName().equals("execute_script")) {
                    if (!pathStack.contains(arguments[0])) {
                        pathStack.push(arguments[0]);
                    } else {
                        pathStack.pop();
                        throw new InvalidFileException("Обнаружена рекурсия в скрипте.");
                    }
                }
                Invoker invoker = new Invoker();
                Response response = invoker.executeCommand(request);
                System.out.println("Команда выполнена.");
                byte[] dataToSend = serialize(response);
                DatagramPacket responsePacket = new DatagramPacket(
                        dataToSend, dataToSend.length,
                        packet.getAddress(), packet.getPort()
                );
                datagramSocket.send(responsePacket);
            }
        } catch (InvalidFileException e) {
            throw new InvalidFileException(e.getMessage());
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    public static CollectionManager getCollectionManager(){
        return collectionManager;
    }

    private static Command findCommand(String commandString) {
        Command command = commands.get(commandString);
        if (command == null){
            throw new InvalidCommandException();
        }
        return command;
    }
}