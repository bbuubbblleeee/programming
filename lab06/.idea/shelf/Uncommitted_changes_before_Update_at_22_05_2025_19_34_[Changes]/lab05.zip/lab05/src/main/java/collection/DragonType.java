package collection;

/**
 * Type enumeration.
 */
public enum DragonType {
    WATER,
    UNDERGROUND,
    AIR,
    FIRE
}
