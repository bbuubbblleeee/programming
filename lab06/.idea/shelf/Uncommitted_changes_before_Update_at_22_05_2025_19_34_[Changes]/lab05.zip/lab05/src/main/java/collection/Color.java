package collection;

/**
 * Color enumeration.
 */

public enum Color {
    GREEN,
    BLACK,
    WHITE
}

