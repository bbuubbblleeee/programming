package collection;

/**
 * Character enumeration.
 */
public enum DragonCharacter {
    CUNNING,
    WISE,
    CHAOTIC
}
